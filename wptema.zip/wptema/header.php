<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if ( is_single() ) { ?><?php wp_title(''); ?><?php } else { ?><?php bloginfo('name'); ?><?php } ?></title>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i|Open+Sans:400,400i|Asap:400,400i,600,600i">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i|Open+Sans:400,400i|Asap:400,400i,600,600i">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/normalize.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/helper.old.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/helper.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/main.css">

<link rel='stylesheet' id='kfi-css-css'  href='<?php bloginfo('template_url'); ?>/tasarim/tasarim2.css?ver=4.9.3' type='text/css' media='all' /
<link type="text/css" rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/global.css" />
<link type="text/css" rel="stylesheet" href="<?php bloginfo('template_url'); ?>/tasarim/css3.css" />

<link href="<?php bloginfo('template_url'); ?>/tasarim/bootstrap.min.css" rel="stylesheet">
<link href="<?php bloginfo('template_url'); ?>/tasarim/mdb.min.css" rel="stylesheet">
<link href="<?php bloginfo('template_url'); ?>/tasarim/style.css" rel="stylesheet">


<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/hint.css" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link href='http://fonts.googleapis.com/css?family=Romanesco&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/fontlar/prox/stylesheet.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/fontlar/freestyle/stylesheet.css" type="text/css" media="all" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/fontawesome/css/font-awesome.css"/>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/fontawesome/css/font-awesome.min.css"/>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/animate/animate.css"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

<?php for ($ar=1; $ar<=get_option('posts_per_page'); $ar++) { ?>
<script type="text/javascript">
$(function(){
$('.acilyaziacil<?php echo $ar; ?>').click(function () {
$('.kirkharamilergeliyor<?php echo $ar; ?>').slideToggle(); }); });
</script>
<?php } ?>

	<script>
		$(function(){
			
			$(".cepecevre").hide().delay(1000).fadeIn();
			
		});
	</script>

<meta name="language" content="tr-TR" />
<meta name="location" content="türkiye, tr, turkey" />
<meta name="robots" content="all" />

<?php wp_head(); ?>
<?php echo get_option('analytics'); ?>
</head>
<body>

	<body class="ts-page ts-page--index">
		<!-- start: header -->
<a id="top" name="top"></a>

<a class="skippy ts-sr-only ts-sr-only--focusable" href="#content">
	<div class="container">
		<span class="skippy__text">Skip to main content</span>
	</div>
</a>
<header class="header">
<div class="container">
<div class="header__content">
<h1 class="header-title" data-option="icon" data-font="asap">
<a class="header-title__link" href="http://aimterror.com/wp/" data-tippy="Hep Beraber Geleceğe">
<i class="header-title__logo"></i>
<i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i>
</a>
</h1>
<div class="search-browser">
<a class="search-browser__link" href="https://www.google.com/search?q=Aimterror İle Hep Beraber Geleceğe Forum Platformu" target="_blank" title="Google: Aimterror İle Hep Beraber Geleceğe Forum Platformu">
<i class="search-browser__icon fab fa-google"></i>
</a>
<a class="search-browser__link" href="https://www.yandex.com.tr/search/?text=Aimterror İle Hep Beraber Geleceğe Forum Platformu" target="_blank" title="Yandex: Aimterror İle Hep Beraber Geleceğe Forum Platformu">
<i class="search-browser__icon fab fa-yandex-international"></i>
</a>
</div>
<div class="beta">
<span class="beta__text">Beta</span>
<span class="beta__sep">&bull;</span>
<a class="beta__link" href="https://webdiyo.com/contact.php" title="Hata bildir">
<i class="beta__icon fas fa-bug"></i>
</a>
</div>



<div class="user-panel user-panel--guest">
<a class="user-panel__item" href="http://aimterror.com/wp/" onclick="$('#quick_login').modal({ fadeDuration: 250, keepelement: true, zIndex: (typeof modal_zindex !== 'undefined' ? modal_zindex : 9999) }); return false;" title="Giriş">
<i class="user-panel__icon fas fa-sign-in-alt"></i>
<span class="user-panel__text">Giriş</span>
</a>
<a class="user-panel__item" href="http://aimterror.com/wp/" title="Kayıt Ol">
<i class="user-panel__icon fas fa-user-plus"></i>
<span class="user-panel__text">Kayıt Ol</span>
</a>
<a class="user-panel__item" href="http://aimterror.com/wp/" title="Yardım">
<i class="user-panel__icon fas fa-question"></i>
<span class="user-panel__text">Yardım</span>
</a>
</div>
<div class="modal" id="quick_login" style="display: none;">
<table width="100%" cellspacing="0" cellpadding="16" border="0" class="tborder">
<tr>
<td class="thead" colspan="2"><strong>Oturum Aç</strong></td>
</tr>

<tr>
<td class="trow1" width="25%"><strong>Kullanıcı Adı:</strong></td>
<td class="trow1"><input name="quick_username" id="quick_login_username" type="text" value="" class="textbox initial_focus" /></td>
</tr>
<tr>
<td class="trow2"><strong>Şifre:</strong></td>
<td class="trow2">
<input name="quick_password" id="quick_login_password" type="password" value="" class="textbox" /> <a href="aimterror.com" class="lost_password">Şifremi Unuttum?</a>
</td>
</tr>
<tr>
<td class="trow1">&nbsp;</td>
<td class="trow1 remember_me">
<input name="quick_remember" id="quick_login_remember" type="checkbox" value="yes" class="checkbox" checked="checked" />
<label for="quick_login_remember">Beni Hatırla</label>
</td>
</tr>
<tr>
<td class="trow2" colspan="2">
<div align="center"><input name="submit" type="submit" class="button" value="Oturum Aç" /></div>
</td>
</tr>

</table>
</form>
</div>
<script type="text/javascript">
	$("#quick_login input[name='url']").val($(location).attr('href'));
</script>

</div>
</div>
</header>
<?php
$get_cat        = get_the_category();
$first_cat      = $get_cat[0];
$category_name  = $first_cat->cat_name;
$category_link  = get_category_link( $first_cat->cat_ID );
?>
<div class="top-panel">
	<div class="container">
		<div class="top-panel__content">
			<nav class="nav ts-margin--right-auto">
				<a class="nav__link nav__link--home" href="http://aimterror.com/wp/">
					<i class="nav__icon fas fa-home"></i>
					<span class="nav__text">Ana Sayfa</span>
				</a>
				<!-- start: header_menu_portal -->
<a class="nav__link nav__link--portal" href="/category/html-html-5/">
	<i class="nav__icon fab fa-css3-alt"></i>
	<span class="nav__text">HTML / HTML 5</span>
</a>
<!-- end: header_menu_portal -->
				<!-- start: header_menu_search -->
<a class="nav__link nav__link--search" href="/category/javascript-jquery/">
	<i class="nav__icon fab fa-js"></i>
	<span class="nav__text">JAVASCRİPT / JQUERY</span>
</a>
<!-- end: header_menu_search -->
				<!-- start: header_menu_memberlist -->
<a class="nav__link nav__link--member" href="/category/linux/">
	<i class="nav__icon fab fa-linux"></i>
	<span class="nav__text">LİNUX</span>
</a>

			<a class="nav__link nav__link--member" href="/category/php/">
	<i class="nav__icon fab fa-php"></i>
	<span class="nav__text">PHP</span>
</a>

<a class="nav__link nav__link--member" href="/category/shell-bash/">
	<i class="nav__icon fab fa-slack-hash"></i>
	<span class="nav__text">SHELL / BASH</span>
</a>

			</nav>
			<nav class="nav ts-margin--left-auto">
				<a class="nav__link nav__link--social" id="navSocial" href="#">
					<i class="nav__icon fas fa-share-alt"></i>
					<span class="nav__text">Sosyal Medya</span>
				</a>
			</nav>
		</div>
	</div>
</div>


<div class="popup" id="navSocial_popup">
	<div class="popup__content">
		<a class="popup__item" href="https://www.facebook.com/" rel="nofollow" target="_blank">
			<i class="popup__icon fab fa-facebook fa-fw"></i>
			<span class="popup__text">Facebook</span>
		</a>
		<a class="popup__item" href="https://www.facebook.com/groups/" rel="nofollow" target="_blank">
			<i class="popup__icon fas fa-user-friends fa-fw"></i>
			<span class="popup__text">Facebook Grubumuz</span>
		</a>
		<a class="popup__item" href="https://www.instagram.com/" rel="nofollow" target="_blank">
			<i class="popup__icon fab fa-instagram fa-fw"></i>
			<span class="popup__text">Instagram</span>
		</a>
	</div>
</div>


<br><div class="container">
					  <div class="row">
						<div class="col">
						 
						 

