<?php get_header(); ?>


									

									
<div class="cerceve">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php

$get_cat        = get_the_category();
$first_cat      = $get_cat[0];
$category_name  = $first_cat->cat_name;
$category_link  = get_category_link( $first_cat->cat_ID );

?>
<div class="hero">
<a class="hero__next hero__next--oldest" href="<?php the_permalink() ?>" rel="nofollow" title="Önceki Konu">
<i class="hero__icon hero__icon--next fas fa-chevron-left"></i>
</a>
<div class="hero__content">
<div class="hero__upper">
<span class="hero__badge hero__badge--sticky" title="Sabit" data-status="0">
<i class="hero__icon fas fa-thumbtack"></i>
</span>
<span class="hero__badge hero__badge--closed" title="Kapalı" data-status="">
<i class="hero__icon fas fa-lock"></i>
</span>
<h1 class="hero__title"><?php the_title(); ?></h1>
</div>
<div class="hero__lower">
<div class="hero__item">
<i class="hero__icon fas fa-code"></i>
<span class="hero__text" title="ID: 23316">1</span>
</div>
<div class="hero__item">
<i class="hero__icon far fa-user"></i>
<a class="hero__link" href="<?php the_permalink() ?>" title="Yazar: <?php the_author(); ?>"><?php the_author(); ?></a>
</div>
<div class="hero__item">
<i class="hero__icon far fa-circle"></i>
<a class="hero__link" href="<?php the_permalink() ?>" title="Kategori: Sohbet "><?php echo esc_html( $category_name ); ?> </a>
</div>
<div class="hero__item">
<i class="hero__icon far fa-comments"></i>
<span class="hero__text" title="Yorum: <?php comments_number(__('0 Yorum'), __('1 Yorum'), __('% Yorum')); ?>"><?php comments_number(__('0 Yorum'), __('1 Yorum'), __('% Yorum')); ?></span>
</div>
</div>
</div>
<a class="hero__next hero__next--newest" href="<?php the_permalink() ?>" rel="nofollow" title="Sonraki Konu">
<i class="hero__icon hero__icon--next fas fa-chevron-right"></i>
</a>
</div>
<div class="page-control page-control--top">
<div class="page-control__item">
</div>
<div class="page-control__item">
</div>
<div class="ts-spacer"></div>
<div class="page-control__item">
</div>
</div>
	<div class='card-deck mb-3'> 
		<div class='card promoting-card'>
			<div class='card-body d-flex flex-row'> 

    <!-- Avatar -->

    <!-- Content -->
   

  </div>

  <!-- Card image -->
  <div class='view overlay'>
    <img height='300px' class='card-img-top rounded-0' src='https://resmim.net/f/ndlie2.jpg?nocache' alt='DDOS Attack'>
    <a href='<?php the_permalink() ?>'>
      <div class='mask rgba-white-slight'></div>
    </a>
  </div>

  <!-- Card content -->
  <div class='card-body'>

    <div class='collapse-content'>





<p style="text-align:center"><?php the_content();?></p>
</p>
   


    </div>

  </div>

</div>


  
</div>
			
					</div>
					
	<?php endwhile; else: ?>
	
	<?php endif; ?>
</div>



																																<div class="col-md-4">
						<!-- Card -->
<div class="card mb-3">

  <div class="card-body">

  <center> <B>About Me ? <B> </center>
	
	<br><center> <B>{ I'm an engineer from Turkey, who is interested with biotechology, computer science and digital gaming. } </center> <B> 


  </div>

</div>


<table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-ad fa-fw"></i><span class="table__head-title-text">Kategoriler</span></h2></div></td></tr></thead><tbody><tr><td class="table__row text-small"><?php wp_list_cats('title='); ?></td></tr></tbody></table>




<br><table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-chart-line fa-fw"></i><span class="table__head-title-text">En Çok Okunan Konular</span></h2></div></td></tr></thead><tbody><tr><td class="table__row text-small"><a><?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 5"); foreach ($result as $post) { setup_postdata($post);$postid = $post->ID; $title = $post->post_title; $commentcount = $post->comment_count; if ($commentcount != 0) { ?> <li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>"><?php echo $title ?></a> {<?php echo $commentcount ?>}</li><?php } } ?></a></td></tr></tbody></table>




<?php
$toplam_yazi = wp_count_posts( 'post' );
$toplam_yazi = $toplam_yazi->publish;
$toplam_kategori = wp_count_terms('category');
$toplam_yorum = get_comment_count();
$toplam_yorum = $toplam_yorum['approved'];

?><br>
<table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-image fa-fw"></i><span class="table__head-title-text">Reklam Alanı</span></h2></div></td></tr></thead><tbody><tr><td class="table__row" align="center"><img src='http://resimag.com/p1/a06aef836bc.png'></td></tr></tbody></table>
<br><div class="card mb-3 px-3 py-3" >
		<header class="panel-header">
		<h2 class="panel-header-title">
			<i class="panel-header-title-icon fas fa-chart-pie fa-fw" aria-hidden="true"></i>
			<span class="panel-header-title-text">İstatistikler</span>
		</h2>
	</header>
	<div class="panel-list" role="list">
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam konu sayısı">Toplam Kategori Sayısı			<a><br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_kategori; ?></abbr>
			<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>
		</div>
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam mesaj sayısı">Toplam Yazı Sayısı<br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_yazi; ?></abbr>
						<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>			
		</div>
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam üye sayısı">Toplam Yorum Sayısı <br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_yorum; ?></abbr>
			<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>
		</div>
		<!-- start: index_panel_last_registered -->
		

</div></div></div></div>

					  

					  


<?php get_footer(); ?>