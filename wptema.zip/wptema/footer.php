<div class="ts-r10-panel">
			<div class="ts-r10-panel__top">
				<div class="ts-r10-panel__item">
					<span class="ts-r10-panel__label">
						<i class="ts-r10-panel__label-icon fas fa-globe"></i>
					</span>
					<span class="ts-font-weight--medium ts-text-transform--uppercase">Genel sorunlar</span>
					<span class="ts-text--muted">support@bugresearcher.com</span>
				</div>
				<div class="ts-r10-panel__item">
					<span class="ts-r10-panel__label">
						<i class="ts-r10-panel__label-icon fas fa-ban"></i>
					</span>
					<span class="ts-font-weight--medium ts-text-transform--uppercase">Ban sorunları</span>
					<span class="ts-text--muted">root@bugresearcher.com</span>
				</div>
				<div class="ts-r10-panel__item">
					<span class="ts-r10-panel__label">
						<i class="ts-r10-panel__label-icon fas fa-lira-sign"></i>
					</span>
					<span class="ts-font-weight--medium ts-text-transform--uppercase">Reklam vermek</span>
					<span class="ts-text--muted">sysadmin@bugresearcher.com</span>
				</div>
			</div>
			<div class="ts-r10-panel__bottom">
				<div class="ts-r10-panel__legal">
					İçerik sağlayıcı paylaşım sitesi olarak hizmet veren <i class="fas fa-link"></i> http://www.aimterror.com</code> adresimizde 5651 Sayılı Kanun'un 8. Maddesine ve <abbr title="Türk Ceza Kanunu">T.C.K</abbr>'nın 125. Maddesine göre tüm üyelerimiz yaptıkları paylaşımlardan kendileri sorumludur. <strong>Benim forum</strong> hakkında yapılacak tüm hukuksal şikayetleri <a class="ts-r10-panel__legal-link" href="http://www.aimterror.com/contact.php">Contact Us <i class="fas fa-external-link-alt"></i></a> bağlantısından bize ulaşıldıktan en geç 3 (üç) gün içerisinde ilgili kanunlar ve yönetmelikler çerçevesinde tarafımızca incelenerek, gereken işlemler yapılacak ve site yöneticilerimiz tarafından bilgi verilecektir.
				</div>
				<div class="ts-r10-panel__copyright">
					
				
				</div>
			</div>
		</div>



	</div>
	<br><br>
	
	<script language="javascript" src="<?php bloginfo('template_url'); ?>/tasarim/yukari.js"></script>
<div class="footer__upper">
<div class="container">
<div class="footer__content">
<i class="header-title__icon fab fa-mailchimp" style="font-size: 2.5rem" data-color-cycle="on"></i>
<span class="header-title__text header-title__text--full" style="padding-left: 1rem;margin-left:1rem;border-left: 1px solid #ccc;font-family: 'Asap', sans-serif;font-weight: 500;font-size:26px;font-style:italic" data-color-cycle="on">AimTerror.Com</span>
<div class="footer__support">
AimTerror.Com (1.5.0) teması
<i class="footer__support-icon footer__support-icon--html fab fa-html5" title="HTML5"></i>
ve
<i class="footer__support-icon footer__support-icon--css fab fa-css3" title="CSS3"></i>
için tam uyumludur.
</div>
</div>
</div>
</div>
<div class="footer__middle">
<div class="container">
<div class="footer__content">
<div class="footer__item">
<h4 class="footer__title">Hakkımızda</h4>
<p class="footer__paragraph">
AimTerror.Com 2016 yılından beri kendimizi tamamen siz değerleri takipçilerimize nasıl daha iyi hizmet veririz diğe düşünerek geçiren bir ekibe sahip olup 3 yılı aşkın süredir her gün #BugResearcher diyerek hizmet veriyoruz.
</p>
</div>
<div class="footer__item">
<h4 class="footer__title">Bağlantılar</h4>
<nav class="footer__nav">
<a class="footer__nav-link" href="#">
<i class="footer__nav-icon fas fa-home fa-fw"></i>
AimTerror.Com
</a>

<a class="footer__nav-link" href="#">
<i class="footer__nav-icon fas fa-envelope fa-fw"></i>
İletişim
</a>

<a class="footer__nav-link" href="#">
<i class="footer__nav-icon fas fa-archive fa-fw"></i>
Arşiv
</a>
<a class="footer__nav-link" href="#">
<i class="footer__nav-icon fas fa-check-double fa-fw"></i>
Kategoriler
</a>
<a class="footer__nav-link" href="#">
<i class="footer__nav-icon fas fa-rss fa-fw"></i>
RSS Beslemesi
</a>
</nav>
</div>
<div class="footer__item">
<h4 class="footer__title">Sosyal</h4>
<nav class="footer__nav">
<a class="footer__nav-link" rel="nofollow noopener" href="#" target="_blank">
<i class="footer__nav-icon fab fa-facebook fa-fw"></i>
Facebook
</a>
<a class="footer__nav-link" rel="nofollow noopener" href="#" target="_blank">
<i class="footer__nav-icon fab fa-instagram fa-fw"></i>Instagram
</a>
</nav>
<span class="footer__divider">-</span>
<h4 class="footer__title">Projelerimiz</h4>
<nav class="footer__nav">
<a class="footer__nav-link" rel="nofollow noopener" href="#" target="_blank">
<i class="footer__nav-icon fas fa-bug fa-fw"></i>BugResearcher
</a>
</nav>
</div>
<div class="footer__item">
<h4 class="footer__title">İletişim</h4>
<p class="footer__paragraph">
<a class="footer__link" href="#">İletişim</a> sayfamızı kullanabilirsiniz.
</p>
<span class="footer__divider">- ya da -</span>
<div class="footer__nav">
<a class="footer__nav-link" rel="nofollow" href="#">
<i class="footer__nav-icon footer__nav-icon--mail fas fa-envelope fa-fw"></i>
<span class="__cf_email__" data-cfemail="e48d8a828ba4938186808d9d8bca878b89">root@bugreserarcher.com</span>
</a>
</div>
</div>
</div>
</div>
</div>

<div class="footer__lower">
<div class="container">
<div class="footer__content">
<div class="footer__copyright">
<i class="footer__copyright-icon far fa-copyright fa-fw"></i> Tema software by <a class="footer__link" rel="noopener nofollow" href="#" target="_blank">BugResearcher</a>
</div>
<div class="footer__mdtoff">
<i class="footer__mdtoff-icon footer__mdtoff-icon--code fas fa-code fa-fw"></i> with by <i class="footer__mdtoff-icon footer__mdtoff-icon--heart far fa-heart fa-fw"></i> <a class="footer__link" rel="noopener nofollow" href="#" target="_blank">BugResearcher</a>
</div>
</div>
</div>
</div>
</footer>
</div>
</body>
</html>