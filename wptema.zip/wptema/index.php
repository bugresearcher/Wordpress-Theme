<?php get_header(); ?>
<?php $i=1; if (have_posts()) : while (have_posts($i<=get_option('posts_per_page'))) : the_post(); ?>
	
		
	
<div class="kfi_card kfi_card-1">

			<div class="kfi_thumb">
<div class="item">
			 <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img class="resim-zoom" src="http://hdqwalls.com/wallpapers/i-love-linux.jpg" alt="<?php the_title(); ?>" width="175"></a>
<div class="item-overlay top"></div>
</div>
					</div>
<a href="http://twitter.com" style="
    margin-right: auto;
    color: #ffffff;
    background: rgba(142,68,173,1) 0%;
    float: right;
    padding: 11px;"><i class="fa fa-twitter"></i></a>
		<div class="kfi_card-content">

							<h2 class="post-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

					

				<p><?php the_excerpt();?> </p>

			<div class="kfi_btn-down">

				<a href="<?php the_permalink() ?>">Devamını Oku</a>
				<a href="http://facebook.com" style="
    margin-right: auto;
    color: #ffffff;
    background: rgba(142,68,173,1) 0%;
    float: right;
    " ><i class="fa fa-facebook"></i></a>
	
						
						
					

		</div>

	</div>

</div>


										
<?php $i++; endwhile; else: ?>
<?php endif; ?>

</div>


																<div class="col-md-4">
						<!-- Card -->
<div class="card mb-3">

  <div class="card-body">

  <center> <B>About Me ? <B> </center>
	
	<br><center> <B>{ I'm an engineer from Turkey, who is interested with biotechology, computer science and digital gaming. } </center> <B> 


  </div>

</div>


<table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-ad fa-fw"></i><span class="table__head-title-text">Kategoriler</span></h2></div></td></tr></thead><tbody><tr><td class="table__row text-small"><?php wp_list_cats('title='); ?></td></tr></tbody></table>




<br><table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-chart-line fa-fw"></i><span class="table__head-title-text">En Çok Okunan Konular</span></h2></div></td></tr></thead><tbody><tr><td class="table__row text-small"><a><?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 5"); foreach ($result as $post) { setup_postdata($post);$postid = $post->ID; $title = $post->post_title; $commentcount = $post->comment_count; if ($commentcount != 0) { ?> <li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>"><?php echo $title ?></a> {<?php echo $commentcount ?>}</li><?php } } ?></a></td></tr></tbody></table>




<?php
$toplam_yazi = wp_count_posts( 'post' );
$toplam_yazi = $toplam_yazi->publish;
$toplam_kategori = wp_count_terms('category');
$toplam_yorum = get_comment_count();
$toplam_yorum = $toplam_yorum['approved'];

?><br>
<table class="table m-bottom" cellspacing="0" cellpadding="16"><thead><tr><td class="table__head"><div class="table__head-inner"><h2 class="table__head-title"><i class="table__head-title-icon fas fa-image fa-fw"></i><span class="table__head-title-text">Reklam Alanı</span></h2></div></td></tr></thead><tbody><tr><td class="table__row" align="center"><img src='http://resimag.com/p1/a06aef836bc.png'></td></tr></tbody></table>
<br><div class="card mb-3 px-3 py-3" >
		<header class="panel-header">
		<h2 class="panel-header-title">
			<i class="panel-header-title-icon fas fa-chart-pie fa-fw" aria-hidden="true"></i>
			<span class="panel-header-title-text">İstatistikler</span>
		</h2>
	</header>
	<div class="panel-list" role="list">
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam konu sayısı">Toplam Kategori Sayısı			<a><br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_kategori; ?></abbr>
			<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>
		</div>
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam mesaj sayısı">Toplam Yazı Sayısı<br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_yazi; ?></abbr>
						<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>			
		</div>
		<div class="panel-list-item d-flex ai-center jc-between" role="listitem">
			<abbr class="s-14" data-tippy="Toplam üye sayısı">Toplam Yorum Sayısı <br><i class="fas fa-angle-double-right"></i> <?php echo $toplam_yorum; ?></abbr>
			<span class="s-16"><i class="header-title__icon fab fa-mailchimp" data-color-cycle="on"></i></span>
		</div>
		<!-- start: index_panel_last_registered -->
		

</div></div></div></div>

						
		
					  
					  

					  
<div class="animated fadeInUpBig">
<div class="right"><?php next_posts_link('Sonraki Sayfa <i class="icon-caret-right"></i>') ?></div>
<div class="left"><?php previous_posts_link('<i class="icon-caret-left"></i> Önceki Sayfa') ?></div>
</div>
<div class="persil"></div>

<?php get_footer(); ?>