<?php get_header(); ?>
<div class="cerceve">
	<div class="dortyuzdort">Böyle bir sayfa yok veya silinmiş.</div>
</div>
<?php get_footer(); ?>